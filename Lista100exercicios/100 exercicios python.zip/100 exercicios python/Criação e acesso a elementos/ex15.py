#Crie uma lista com 3 números e outra com 3 letras, e concatene as duas listas.

lista1 = [12, 43, 56]
lista2 = ["A", "B", "C"]

listaconcatenada = lista1 + lista2

print(listaconcatenada)