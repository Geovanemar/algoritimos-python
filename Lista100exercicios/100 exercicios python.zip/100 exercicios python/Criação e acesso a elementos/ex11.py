#Crie uma lista com 8 elementos e exiba os 4 primeiros.

lista = [1, 2, 3, 4, 5, 6, 7, 8]

print(lista[0:4])