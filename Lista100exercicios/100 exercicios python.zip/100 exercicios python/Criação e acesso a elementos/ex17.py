#Crie uma lista com 10 elementos e exiba o tamanho da lista.

lista = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

print(len(lista))