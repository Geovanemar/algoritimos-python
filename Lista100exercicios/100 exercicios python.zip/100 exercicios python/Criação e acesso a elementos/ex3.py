lista = []
lista.append(10)
lista.append(20)
lista.append(30)

print(lista)