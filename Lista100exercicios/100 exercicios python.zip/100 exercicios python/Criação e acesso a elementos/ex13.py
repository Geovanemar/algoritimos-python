#Crie uma lista com os números de 1 a 5 e exiba do segundo ao quarto elemento.

lista = (1, 2, 3, 4, 5)

print(lista[2:5])