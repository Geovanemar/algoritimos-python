#Crie uma lista com 6 elementos e exiba seu tamanho com len().

lista = [45, 56, 78, 97, 86]

print(len(lista))