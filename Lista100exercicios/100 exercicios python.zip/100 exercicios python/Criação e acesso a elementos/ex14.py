#Crie uma lista com 5 frutas e exiba-a duas vezes seguidas.

lista = ["banana", "maça", "laranja", "pera", "cereja"]

print(lista)
print(lista)

