#Crie uma lista com 6 números e exiba o segundo e o quinto elementos.

lista = [1, 2, 3, 4, 5, 6]
print(lista[1])
print(lista[5])