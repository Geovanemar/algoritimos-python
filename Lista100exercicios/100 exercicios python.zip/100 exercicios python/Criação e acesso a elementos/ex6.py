#Crie uma lista com os números de 1 a 10 e exiba o terceiro elemento.

lista = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

print(lista[2])