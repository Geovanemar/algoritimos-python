#Crie uma lista com 7 elementos e exiba os 3 últimos.

lista = [1, 2, 4, 5, 6, 7]

print(lista[3:7])