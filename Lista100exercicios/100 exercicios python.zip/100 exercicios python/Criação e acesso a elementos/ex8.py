#Crie uma lista com os nomes de 4 cidades e exiba o terceiro nome.

lista = ["são paulo", "campo grande", "tocantins", "fortaleza"]

print(lista[2])