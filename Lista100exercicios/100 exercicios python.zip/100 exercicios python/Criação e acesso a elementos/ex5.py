lista = [1, 2, 3]

print(lista[2])