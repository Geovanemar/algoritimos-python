nomes = ["alanna", "matheus", "marcos", "carla", "sofia"]
print(nomes)