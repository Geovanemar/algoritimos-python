#Crie uma lista com os números 1, 2, 3, 4 e 5 e exiba a lista completa.

lista = [1, 2, 3, 4, 5]
 
print(lista[0:5])