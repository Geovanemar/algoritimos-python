lista = [34, 56, 67, 23, 89, 67]

lista_ordenada = sorted(lista)

print(lista_ordenada)