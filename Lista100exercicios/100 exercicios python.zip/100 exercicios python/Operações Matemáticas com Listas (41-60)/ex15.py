lista = [-10, 20, -30, 40, -50]

lista_abs = [abs(x) for x in lista]
print(lista_abs)