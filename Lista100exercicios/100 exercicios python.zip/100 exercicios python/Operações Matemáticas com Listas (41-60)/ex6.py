lista = [2, 4, 6, 7, 5, 7, 8, 9]

maior_valor = max(lista)

lista.remove(maior_valor)

segundo_maior = max(lista)
print(segundo_maior)

