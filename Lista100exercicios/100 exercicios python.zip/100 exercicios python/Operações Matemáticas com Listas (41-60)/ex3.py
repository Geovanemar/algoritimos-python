lista = (1, 2, 3, 4, 5)

lista_elevada = [x ** 2 for x in lista]
print(lista_elevada)