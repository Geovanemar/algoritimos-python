lista = (1, 2, 3, 4, 5)

lista_soma = [x + 10 for x in lista]

print(lista_soma)