lista = (1, 2, 3, 4, 5)

lista_multiplicada = [x * 2 for x in lista]

print(lista_multiplicada)