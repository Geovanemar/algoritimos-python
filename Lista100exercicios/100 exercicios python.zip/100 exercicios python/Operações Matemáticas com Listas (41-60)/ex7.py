lista = (1, 2, 3, 4, 5)

primeiro_menor = min(lista)

lista.remove(primeiro_menor)

segundo_menor = min(lista)
print(segundo_menor)