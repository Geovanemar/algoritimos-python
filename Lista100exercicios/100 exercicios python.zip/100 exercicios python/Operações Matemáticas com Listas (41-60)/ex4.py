lista = (1, 2, 3, 4, 5)

lista1 = 1

for num in lista:
    lista1 *= num

    print(lista1)
