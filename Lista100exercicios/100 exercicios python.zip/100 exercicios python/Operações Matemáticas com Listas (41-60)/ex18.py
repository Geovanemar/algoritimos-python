lista1 = (1, 2, 3, 4, 5)
lista2 = (6, 7, 8, 9, 10)

lista_conc = lista1 + lista2
print(lista_conc)