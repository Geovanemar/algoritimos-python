lista = [34, 56, 67, 23, 89, 67]

lista = sorted(lista, reverse=True)
print(lista)