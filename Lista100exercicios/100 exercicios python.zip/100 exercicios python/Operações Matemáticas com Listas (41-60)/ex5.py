lista = [2, 4, 6, 7, 5, 7, 8, 9]


print(sum(lista)/len(lista))

