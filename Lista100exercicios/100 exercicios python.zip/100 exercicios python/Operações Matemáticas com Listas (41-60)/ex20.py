lista = [1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 5, 5, 5]

lista_num = lista.count(5)
print(lista_num)