lista = (1, 2, 3, 4, 5)

lista_invertida = lista[::-1]
print(lista_invertida)

