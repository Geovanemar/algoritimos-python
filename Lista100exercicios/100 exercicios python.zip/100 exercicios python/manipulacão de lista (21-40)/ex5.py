lista = ["banana", "morango", "cereja"]
lista.remove("banana")
print(lista)