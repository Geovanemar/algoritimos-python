lista = ["vaca", "boi", "camelo"]

lista_str = ",".join(lista)

print(lista_str)