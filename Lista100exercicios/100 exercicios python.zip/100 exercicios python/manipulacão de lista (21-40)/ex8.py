lista = ["halter", "polia", "peso", "ana", "mouse", "teclado",]

lista.append("bolsonaro")
print(lista)