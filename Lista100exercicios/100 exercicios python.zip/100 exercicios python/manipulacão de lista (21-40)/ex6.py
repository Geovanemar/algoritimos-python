lista = ["halter", "polia", "peso", "ana", "mouse", "teclado", "noise"]

lista.pop()
print(lista)