lista1 = ["vanessa", "marcos", "ronaldo", "pedro"]


lista2 = lista1.copy()

print("\nlista1:", lista1)
print(" copia da lista: " , lista2)
