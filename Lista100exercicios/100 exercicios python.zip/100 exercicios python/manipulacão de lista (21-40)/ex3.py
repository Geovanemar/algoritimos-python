lista = ["joana", "jow", "ronaldo", "marcos"]

lista[0]= "geovane"
print(lista)