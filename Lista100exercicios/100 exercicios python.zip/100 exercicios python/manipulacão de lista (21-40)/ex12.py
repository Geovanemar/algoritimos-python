lista = [3,7,8,9,3,4,5,6,1,2,]

lista.sort()
print(lista)