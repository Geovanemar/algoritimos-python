lista = ["halter", "polia", "peso", "ana", "mouse", "teclado", "noise"]

lista[6]= "amigo"
print(lista)