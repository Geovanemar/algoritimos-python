lista = ["banana", "maça", "pera", "laranja", "cereja"]
lista[2]="morango"
print(lista)