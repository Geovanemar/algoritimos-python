lista = [3,7,8,9,3,4,5,6,1,2, 3, 5, 3, 7,]

valor = lista.count(3)
print("posição do valor é:", valor)