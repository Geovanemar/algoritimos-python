lista = ["halter", "polia", "peso", "ana", "mouse", "teclado", "noise"]

lista.reverse()
print(lista)