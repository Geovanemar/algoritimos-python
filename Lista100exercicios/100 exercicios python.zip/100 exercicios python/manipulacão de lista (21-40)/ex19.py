lista1 = ["vanessa", "marcos", "ronaldo", "pedro"]

lista1.clear()
print(lista1)