lista = ["joana", "jow", "ronaldo", "marcos"]

del lista[2]
print(lista)