lista = ["halter", "polia", "peso", "ana", "mouse", "teclado", "noise"]

nova_lista = ("luis", "marrom", "branco")
lista.extend(nova_lista)
print(lista)

