lista = ["halter", "polia", "peso", "ana", "mouse", "teclado",]

lista.insert (1, "bolsonaro")
print(lista)