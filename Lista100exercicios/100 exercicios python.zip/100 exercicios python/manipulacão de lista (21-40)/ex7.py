lista = ["halter", "polia", "peso", "ana", "mouse", "teclado", "noise"]

lista.pop(0)
print(lista)
