lista = ["halter", "polia", "peso", "ana", "mouse", "teclado",]

posição = lista.index("peso")
print(lista)
print("peso esta na posição:", posição)