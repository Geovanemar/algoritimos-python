lista = ["joana", "zoe", "ronaldo", "marcos", "sofia", "camilla"]
 
meio = len(lista)//2

lista1 = lista[:meio]
lista2 = lista[ meio:]
print("primeira lista: ", lista1)
print("segunda lista: ", lista2)