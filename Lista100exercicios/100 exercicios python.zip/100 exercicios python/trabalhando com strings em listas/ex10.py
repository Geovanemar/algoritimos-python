lista = ["joana", "zoe", "ronaldo", "marcos", "sofia", "camilla"]

lista_menor_palavra =  min(lista, key=len)

print(lista_menor_palavra)