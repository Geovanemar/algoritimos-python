lista = ["filho da mãe joana", "messi bola de ouro"]

lista_split = [lista.split() for  lista in lista]

print(lista_split)