lista = ["joana", "zoe", "ronaldo", "marcos", "sofia", "camilla", "vic"]

lista_filtrada = [lista for lista in lista if len(lista) >=4]

print(lista_filtrada)