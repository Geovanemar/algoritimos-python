lista = ["joana", "zoe", "ronaldo", "marcos", "sofia", "camilla", "Geovane martins"]

lista_maior_palavra = max(lista, key=len)

print(lista_maior_palavra)