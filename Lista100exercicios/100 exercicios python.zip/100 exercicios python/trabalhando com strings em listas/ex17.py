lista = [1, 2, 3, 4, 5, 6, 7]

lista_rotacionada = lista[1:] + [lista[0]]

print(lista_rotacionada)