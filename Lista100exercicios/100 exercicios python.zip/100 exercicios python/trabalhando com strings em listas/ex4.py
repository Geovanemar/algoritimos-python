lista = ["joana", "jow", "ronaldo", "marcos"]

lista_capitalizada = [lista.capitalize() for lista in lista ]

print(lista_capitalizada)