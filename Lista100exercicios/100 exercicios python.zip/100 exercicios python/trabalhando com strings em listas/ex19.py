lista = [" python " , " C++ " , " java "  , " javasprit " ,  " C "  ]

Lista_sem_espaços = [elemento.replace(" ", "") for elemento in lista]


print(Lista_sem_espaços)