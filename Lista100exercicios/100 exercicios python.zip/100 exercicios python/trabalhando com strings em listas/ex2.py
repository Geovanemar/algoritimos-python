lista = ["joana", "zoe", "ronaldo", "marcos", "amanda", "sofia"]

lista.sort() 

print(lista)