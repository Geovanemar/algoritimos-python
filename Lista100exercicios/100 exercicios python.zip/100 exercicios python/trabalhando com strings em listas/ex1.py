Lista = ["estou" , "programando" , "em" , "python" , "(:"]

lista1 = " " .join(Lista)

print(lista1)