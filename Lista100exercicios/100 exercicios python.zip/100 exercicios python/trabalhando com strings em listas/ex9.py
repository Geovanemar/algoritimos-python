lista = ["joana", "zoe", "ronaldo", "marcos", "sofia", "camilla"]

lista.reverse()

print(lista)