lista = [1, 2, 3]
lista1 = [4, 5, 6, 7, 8, 9, 10]

lista_unida = lista + lista1

print(lista_unida)