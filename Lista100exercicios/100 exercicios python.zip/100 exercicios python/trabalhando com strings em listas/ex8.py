lista = ["joana", "zoe", "ronaldo", "marcos", "sofia", "camilla"]

lista.sort()
print(lista)