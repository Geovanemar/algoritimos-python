lista = ["filho da mãe joana", "messi bola de ouro", "programando em python"]

lista_primeira_palavra = [lista.split()[0] for lista in lista]

print(lista_primeira_palavra)