
lista = [1, 2, 3, 4, 5]

lista_em_strings = [str(lista) for numero in lista]


print(lista_em_strings)
