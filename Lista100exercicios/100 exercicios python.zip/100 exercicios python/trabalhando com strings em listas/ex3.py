lista = ["jOANA", "JOW", "RONALDO", "MARCOS"]

lista_minuscula =[lista.lower() for lista in lista]

print(lista_minuscula)
lista = ["joana", "jow", "ronaldo", "marcos"]

lista_minuscula =[lista.lower() for lista in lista]

print(lista_minuscula)
