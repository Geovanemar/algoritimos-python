lista = ["joana", "jow", "ronaldo", "marcos"]

lista_letra_trocada = [lista.replace("o" , "z") for lista in lista]

print(lista_letra_trocada)