lista = ["joana", "jow", "ronaldo", "marcos"]

lista_title = [lista.title() for lista in lista]

print(lista_title)