class Aluno:
    def __init__(self, nome, matricula):
        self.nome = nome
        self.matricula = matricula

class Disciplina:
    def __init__(self, nome_disc, cod,):
        self.nome_disc = nome_disc
        self.cod = cod

class Nota:
    def __init__(self, valor):
        self.valor = valor        

